import praw
import boto3
import json
import os
from datetime import datetime

reddit = praw.Reddit(
    client_id=os.environ['REDDIT_CLIENT_ID'],
    client_secret=os.environ['REDDIT_CLIENT_SECRET'],
    user_agent="MyAPI/0.0.1"
)

s3 = boto3.client('s3')


def lambda_handler(event, context):
    subreddit = reddit.subreddit('technology')  # Example subreddit
    hot_posts = subreddit.hot(limit=100)
    posts = []
    for post in hot_posts:
        posts.append({
            'id': post.id,
            'title': post.title,
            'score': post.score,
            'num_comments': post.num_comments,
            'created_utc': post.created_utc,
            'selftext': post.selftext
        })
    filename = f"reddit_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json" 
    s3.put_object(
        Bucket=os.environ['S3_BUCKET'],
        Key=f"raw_data/reddit/{filename}",
        Body=json.dumps(posts)
    )
       
    return {
        'statusCode': 200,
        'body': json.dumps(f'Collected {len(posts)} posts from Reddit')
    }
