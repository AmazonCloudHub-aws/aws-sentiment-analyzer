import boto3
import json
import os
from datetime import datetime

s3 = boto3.client('s3')


def get_latest_file(bucket, prefix):
    files = s3.list_objects_v2(Bucket=bucket, Prefix=prefix)
    return max(files['Contents'], key=lambda x: x['LastModified'])


def get_file_content(bucket, key):
    response = s3.get_object(Bucket=bucket, Key=key)
    return json.loads(response['Body'].read())


def save_combined_data(bucket, data):
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f"combined_data_{timestamp}.json"
    key = f"processed_data/{filename}"
    s3.put_object(
        Bucket=bucket,
        Key=key,
        Body=json.dumps(data)
    )


def lambda_handler(event, context):
    bucket = os.environ['S3_BUCKET']
    
    # Get latest Reddit data
    reddit_prefix = 'raw_data/reddit/'
    latest_reddit_file = get_latest_file(bucket, reddit_prefix)
    reddit_data = get_file_content(bucket, latest_reddit_file['Key'])
    
    # Get latest Amazon reviews data
    amazon_prefix = 'raw_data/amazon/'
    latest_amazon_file = get_latest_file(bucket, amazon_prefix)
    amazon_data = get_file_content(bucket, latest_amazon_file['Key'])
    
    # Combine data
    combined_data = {
        'reddit': reddit_data,
        'amazon': amazon_data
    }
    
    # Save combined data
    save_combined_data(bucket, combined_data)
    
    return {
        'statusCode': 200,
        'body': json.dumps('Data integration complete')
    }